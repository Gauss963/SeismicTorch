# SeismicTorch

`EarthquakeCNN` classifies two-second, three-component waveform windows as
P wave, S wave or noise. Each window contains 80 samples per component (40 Hz).
The model takes `[batch, 1, 80, 3]`, uses three convolutions with 16, 32 and 64
filters of size `(3, 1)`, then applies linear layers `384 → 64 → 16 → 3`.

For the current QSIS experiment, use the gravity-aligned candidate at
`runs/qsis-ccul-extra/gravity-record-candidate`. Its 226-source training recipe
uses CWA initialization, reviewed QSIS arrivals, training-only proposals and
noise, and 20 epochs on Apple MPS. The [QSIS reproduction command](QSIS_BENCHMARK.md#reproduce-the-gravity-candidate)
records the exact input manifests and preprocessing. The benchmark report
also separates date-held results, reused reference diagnostics and unresolved
arrival coverage. Experimental candidates remain in their own run folders.

On two prespecified, independently reviewed QSIS cohorts, the retained
checkpoint scored 44/44 at center. Including three later array-context
references gives 46/47 (97.87%) at center and 45/47 (95.74%) at the weakest
of the fixed ±0.2-second offsets. The references are model-blind AI waveform
agreements. Unresolved arrivals stay outside the score and remain reported
in the [coverage and verification summary](QSIS_BENCHMARK.md#current-verified-result).

## Train the waveform model

Use an environment with PyTorch and NumPy. For example, on the local Mac:

```bash
conda activate PyTorch
python train.py pretrain --device mps --output runs/stead
python train.py finetune --device mps --init runs/stead/best.pth --output runs/qsis
```

`--device auto` (the default) prefers CUDA, then Apple MPS, then CPU. Specify a
device explicitly if the run should fail when that device is unavailable.
The defaults match the historical schedule: 50 STEAD epochs and 100 QSIS
epochs. Each run writes the best validation weights (`best.pth`), per-epoch
metrics (`history.jsonl`), and validation and test metrics (`metrics.json`).
Confusion matrices use true labels as rows and predicted labels as columns.

| Stage | Prepared archive | Evaluation split |
|---|---|---|
| STEAD | `data_train/pth/train.pth`, `data_train/pth/test.pth` | 80/20 train/validation from the train archive, separate test archive |
| QSIS | `data_QSIS_pth/all_merged.pth` | 70/15/15 split by recording, with adjacent P/S windows kept together |

The prepared `.pth` files use Git LFS. Run `git lfs pull` if your checkout
contains pointers. These archives contain pickled NumPy arrays, so use trusted
local copies. The loader applies the existing amplitude limits, normalizes each
window by its absolute peak across all three components, and omits the old
int16 round trip. It removes duplicate STEAD training windows before splitting
and drops all copies of any identical window with conflicting labels.

The prepared files lack event and station IDs. QSIS grouping uses the saved
order of windows from each recording, so recordings from different stations
that observed the same event may still land in different splits. STEAD
validation uses a seeded stratified split of windows.

To load the new weights in Python:

```python
import torch
from def_model import EarthquakeCNN

model = EarthquakeCNN()
model.load_state_dict(torch.load("runs/qsis/best.pth", map_location="cpu", weights_only=True))
model.eval()
```

The original [waveform training](model_train_Torch.ipynb) and
[fine-tuning](model_finetune_Torch.ipynb) notebooks contain the historical runs.
The [data preparation script](dataprep.py) and QSIS data preparation notebooks
describe how the waveform archives were created. The original model exports
and their scripts use the old saved-module format.

## Review QSIS arrival times

`qsis_review.py` samples the raw SAC recordings across stations and three
bands of peak amplitude relative to background noise. It writes an offline
review page, waveform plots, and a manifest with the source paths, provisional
event keys, estimated arrival times, and reconstructed legacy windows.

```bash
python -m pip install obspy matplotlib seisbench
python qsis_review.py --output runs/qsis-review --count 100
```

Open `runs/qsis-review/index.html` and enter picks in seconds from the SAC
event origin. Export the review as JSON when finished. PhaseNet uses the
SeisBench STEAD weights locally. Pass `--taup-only` to omit PhaseNet. Both
pickers provide candidate times for review. The legacy overlay shows the
window before random jitter and the envelope of possible shifted windows.

To compare the reconstructed legacy windows with windows centered on reviewed
onsets, use the same STEAD checkpoint for both:

```bash
python qsis_pilot.py --device mps --review runs/qsis-review-balanced \
  --init runs/stead/best.pth --output runs/qsis-onset-pilot
```

The review directory must contain `manifest.json` and `ai-visual-review.json`.
The pilot keeps only picks marked clear and pairs that pass the channel check
in both windows. It holds out one earthquake group and two separate noise days
per fold. Its scores describe the selected, onset-centered clips. They do not
measure performance on continuous recordings.

The [QSIS benchmark protocol](QSIS_BENCHMARK.md) describes the frozen event
split, training-only RED-PAN proposals, and comparison with the small 1D TCN.

To classify one candidate arrival in aligned 100 Hz QSIS SAC files, pass
the center in seconds from the start of the recording. The command prints
the P, S or noise label and the checkpoint hash.

```sh
python qsis_candidate.py predict \
  --candidate runs/qsis-ccul-extra/gravity-record-candidate \
  --center 126.0 --waveform X.sac Y.sac Z.sac
```

Add `--history runs/qsis-context-history/stress-head.pth` to evaluate the
optional history head. It uses nine seconds before the center and
falls back to the CNN when those samples are unavailable or unusable.

To train the untapered high-pass variant, pass `--waveform-filter steady-start`
to `qsis_candidate.py fit`. The checkpoint's training receipt records the
filter, and `predict` and `score` read that choice automatically.

Pass `--gravity-align` during fitting to align the measured static gravity
with the model's vertical component. The estimate uses seconds 1–7 of
the recording, before the classified window, and expects acceleration
in gal. Recordings without a stable gravity baseline keep their input axes.
The training receipt also records this preprocessing for scoring and prediction.

Repeat `--extra-public-review DOWNLOAD MANIFEST CONSENSUS` to append additional
reviewed training cohorts. The fitter records each source and rejects repeated
phase windows. The benchmark includes the [reproduction command](QSIS_BENCHMARK.md#reproduce-the-gravity-candidate)
for the 226-window gravity candidate.

## Spectrogram Model Definition

```python
class SpectrogramCNN(nn.Module):
    def __init__(self):
        super(SpectrogramCNN, self).__init__()

        self.conv1 = nn.Conv2d(in_channels = 3, out_channels = 48, kernel_size = (3, 3), stride = (1, 1))
        self.bn1 = nn.BatchNorm2d(48)
        self.GELU1 = nn.GELU()
        self.maxpool1 = nn.MaxPool2d(kernel_size = (2, 2), stride = (2, 2))
        self.dropout1 = nn.Dropout(p = 0.1)

        self.conv2 = nn.Conv2d(in_channels = 48, out_channels = 96, kernel_size = (3, 3), stride = (1, 1))
        self.bn2 = nn.BatchNorm2d(96)
        self.GELU2 = nn.GELU()
        self.maxpool2 = nn.MaxPool2d(kernel_size = (2, 2), stride = (2, 2))
        self.dropout2 = nn.Dropout(p = 0.1)

        self.conv3 = nn.Conv2d(in_channels = 96, out_channels = 192, kernel_size = (3, 3), stride = (1, 1))
        self.bn3 = nn.BatchNorm2d(192)
        self.GELU3 = nn.GELU()
        self.maxpool3 = nn.MaxPool2d(kernel_size = (2, 2), stride = (2, 2))
        self.dropout3 = nn.Dropout(p = 0.1)

        self.fc1 = nn.Linear(32640, 1280)
        self.GELU4 = nn.GELU()
        self.fc2 = nn.Linear(1280, 64)
        self.GELU5 = nn.GELU()
        self.fc3 = nn.Linear(64, 2)
        

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.GELU1(x)
        x = self.maxpool1(x)
        x = self.dropout1(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.GELU2(x)
        x = self.maxpool2(x)
        x = self.dropout2(x)
        
        x = self.conv3(x)
        x = self.bn3(x)
        x = self.GELU3(x)
        x = self.maxpool3(x)
        x = self.dropout3(x)

        x = x.view(x.size(0), -1)

        x = self.fc1(x)
        x = self.GELU4(x)
        x = self.fc2(x)
        x = self.GELU5(x)
        x = self.fc3(x)

        return x
```
